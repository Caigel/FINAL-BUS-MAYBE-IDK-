# author, Caige laurenti. purpose: a model for a bus map


import tkinter as tk
from tkinter import ttk
from tkinter import *

# creating the main class 
class TimeApp:
    # making the root window 
    def __init__(self, root):
        self.root = root
        self.root.geometry('1000x1000')
        self.root.title("Canvas")
        self.root.configure(bg='black')



        # making some variables to be used elsewhere 
        self.Tree = 1
        self.time = 0
        self.price = 0

        # Create the initial button
        self.start_button = ttk.Button(root, text="Press me to begin", command=self.start_button)
        self.start_button.pack(pady=10)

    def start_button(self):
        # Forget the start button
        self.start_button.pack_forget()

        # This is making the buttons that the user will click to pick their stops 
        self.instruction_label = tk.Label(self.root, text="Please select your current bus stop", bg='black', fg='white')
        self.instruction_label.pack(pady=10)

        self.big_and_wow_button = ttk.Button(self.root, text="Place 1", command=lambda:[self.increment_total_time(60),
                                                                                            self.Price(5),
                                                                                            self.press(1),
                                                                                            self.big_and_wow_button.place_forget()])
        self.big_and_wow_button.place(x=100, y=100)

        self.wow_and_big_button = ttk.Button(self.root, text="Place 2", command=lambda:[self.increment_total_time(30),
                                                                                            self.Price(2),  
                                                                                            self.press(1),         
                                                                                            self.wow_and_big_button.place_forget()])
        self.wow_and_big_button.place(x=100, y=500)

        self.button3 = ttk.Button(self.root, text="Place 3", command=lambda:[self.increment_total_time(90),
                                                                                            self.Price(7),
                                                                                            self.press(1),           
                                                                                            self.button3.place_forget()])
        self.button3.place(x=300, y=100)


        self.button4 = ttk.Button(self.root, text="Place 4", command=lambda:[self.increment_total_time(30),
                                                                                            self.Price(11),
                                                                                            self.press(1),           
                                                                                            self.button4.place_forget()])
        self.button4.place(x=300, y=500)
        

        self.button5 = ttk.Button(self.root, text="Place 5", command=lambda:[self.increment_total_time(60),
                                                                                            self.Price(2),
                                                                                            self.press(1),           
                                                                                            self.button5.place_forget()])
        self.button5.place(x=500, y=100)

        self.button6 = ttk.Button(self.root, text="Place 6", command=lambda:[self.increment_total_time(120),
                                                                                            self.Price(15),
                                                                                            self.press(1),           
                                                                                            self.button6.place_forget()])
        self.button6.place(x=500, y=500)


        self.button7 = ttk.Button(self.root, text="Place 7", command=lambda:[self.increment_total_time(60),
                                                                                            self.Price(8),
                                                                                            self.press(1),           
                                                                                            self.button7.place_forget()])
        self.button7.place(x=700, y=100)


        self.button8 = ttk.Button(self.root, text="Place 8", command=lambda:[self.increment_total_time(30),
                                                                                            self.Price(7),
                                                                                            self.press(1),           
                                                                                            self.button8.place_forget()])
        self.button8.place(x=700, y=500)
        
    
        
    # this is the main function of the buttons 
    def press(self, value):
        # Hide the "BIG AND WOW" button
        # Increment total_time by 1
        self.Tree += value
        # this if statement is to check how many buttons have been clicked so if its over one it goes to the else statement 
        if self.Tree == 2:
            self.instruction_label.pack_forget()
            self.instruction_label_2 = tk.Label(self.root, text="Please select the bus stop where you wish to go", bg='black', fg='white')
            self.instruction_label_2.pack(pady=10)

        # this runs if the self.tree value(the counter of buttons) is over 2, and destroys all children of the window to clear the screen 
        # for the final label to tell the user the time and price of the bus ride    
        else:
            for ele in self.root.winfo_children():
             ele.destroy()
            self.instruction_label_2.pack_forget()
            self.Stand_in = self.time / 60
            self.instruction_label_3 = tk.Label(self.root, text=f"the time between your stops is {self.Stand_in} hours, and will cost you {self.price} dollars.", bg='black', fg='white')
            self.instruction_label_3.place(relx=.5, rely=.5, anchor="center")
            self.instruction_label_3.config(font=("Courier", 18))
            self.close = ttk.Button(self.root, text="Close", command=self.End)
            self.close.pack(pady=10)



            
    def End(self):
        self.root.destroy()
    # this is what is keeping track of the price
    def Price(self, value):
        self.price += value

    # this is whats keeping track of the time
    def increment_total_time(self, value):
        self.time += value
        

    

if __name__ == "__main__":
    # Create the main window
    root = tk.Tk()

    # Create an instance of the TimeApp class
    app = TimeApp(root)

    # Start the main event loop
    root.mainloop()
